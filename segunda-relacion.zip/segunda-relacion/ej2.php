<?php
    $var1 = 10;
    $var2 = 5;
    $suma = $var1 + $var2;
    $resta = $var1 - $var2;
    $multiplicacion = $var1 * $var2;
    $division = $var1 / $var2;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej-2</title>
</head>
<body>
    <?php
        print("<p>Suma: $var1 + $var2 = $suma</p> <p>Resta: $var1 - $var2 = $resta</p>
        <p>Multiplicación: $var1 * $var2 = $multiplicacion</p> <p>División: $var1 / $var2 = $division</p>
        ")
    ?>
</body>
</html>