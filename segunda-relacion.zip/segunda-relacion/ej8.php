<?php
    $valor = 0;

    do {
        $valor ++;
        printf("%d - ",$valor);
    } while ($valor <5);
?>
