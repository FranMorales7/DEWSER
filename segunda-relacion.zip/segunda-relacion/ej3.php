<?php
    $precio = 250;
    $iva = $precio + ($precio * 0.15); //IVA del 15%
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej-3</title>
</head>
<body>
    <?php
        printf("El precio del producto sin I.V.A. es de : %d
        <br/>El precio del producto con I.V.A. es de %d", $precio, $iva
        )
    ?>
</body>
</html>