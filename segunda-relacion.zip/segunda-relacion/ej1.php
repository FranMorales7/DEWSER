<?php
    $nombre = "Fran";
    $edad = 21;
    $ciudad = "Granada";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p><?php 
    print "<p>Nombre: $nombre</p> 
    <p>Edad: $edad</p>
    <p>Ciudad: $ciudad</p>"    
    ?></p>

    <p><?php 
    printf("Hola, soy %s, tengo %d años y vivo en %s.",$nombre, $edad,$ciudad);
    ?></p>
</body>
</html>