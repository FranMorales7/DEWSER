<?php
    $valor = 0;
    while($valor <=10){
        $valor ++;
        if ($valor == 5){
            break;
        }
        printf("%d - ",$valor);
    }
?>