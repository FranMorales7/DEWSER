<!--Opcion 1-->
<?php
    $valor = 0;

    while($valor <20 ){
        $valor += 2;
        printf("%d - ",$valor);
       
    }
    printf("<br/>");
?>
<!--Opcion 2-->
<?php
    for ($valor = 1; $valor <=20; $valor ++) {
        if ($valor % 2 == 0){
            printf("%d - ",$valor);
        }
    }
?>
