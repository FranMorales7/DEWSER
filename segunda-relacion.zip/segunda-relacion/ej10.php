<?php
    for($valor = 1; $valor <=20; $valor ++){
        if($valor % 2 == 0){
            continue; //Tras comprobar que es nº par, lo deja pasar
        }
        printf("%d - ",$valor);
    }
?>