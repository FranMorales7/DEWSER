<?php
    $menor = "eres menor de edad";
    $adulto = "eres adulto";
    $mayor = "perteneces a la tercera edad";
    $edad = 17;
    if ($edad < 18){
        $resultado = $menor;
    } elseif ($edad >= 18 && $edad < 65 ){
        $resultado = $adulto;
    } else {
        $resultado = $mayor;
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej-4</title>
</head>
<body>
    <?php
        printf("- Tengo %d años. <br/> - Entonces %s.",
        $edad, $resultado
        );
    ?>
</body>
</html>